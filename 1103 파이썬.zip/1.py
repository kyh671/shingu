print(10+10)
print(10+10.0)
a=32
b= hex(a)
print(b)
bin(a)
oct(a)
a = 1.2
b = 2.0
c = a.is_integer()
d = b.is_integer()
print(c,d)
import math
e= round(a)
f= math.ceil(a)
g = math.floor(a)
print(e,f,g)
a = "abcde"
print(a[0],a[4])
print(a[-1],a[-5])
a = "Gachon University"
print(a[0:6],"AND",a[-9:])
print(a[:])
print(a[-50:50])
print(a[::2],"AND",a[::-1])
